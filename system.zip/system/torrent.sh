#!/bin/bash

# Color definitions
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[34m"
CYAN="\033[36m"
WHITE="\033[97m"
ENDCOLOR="\033[0m"

# Spinner function
spinner() {
    local pid=$!
    local delay=0.75
    local spinstr='|/-\\'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

# Firewall rules functions
remove_script() {
    iptables -P INPUT ACCEPT
    iptables -P OUTPUT ACCEPT
    iptables -P FORWARD ACCEPT
    iptables -t mangle -F
    iptables -t mangle -X
    iptables -t nat -F
    iptables -t nat -X
    iptables -t filter -F
    iptables -t filter -X
    iptables -F
    iptables -X
    rm -f /etc/Plus-torrent
    sleep 3
}

add_firewall_rules() {
    local arq="/etc/Plus-torrent"
    local IP=$(wget -qO- ipv4.icanhazip.com)
    local NIC=$(ip -4 route ls | grep default | grep -Po '(?<=dev )(\S+)' | head -1)

    echo 'iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT' > $arq
    echo 'iptables -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT' >> $arq
    echo 'iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT' >> $arq
    echo 'iptables -t filter -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT' >> $arq
    echo 'iptables -A OUTPUT -p tcp --dport 53 -m state --state NEW -j ACCEPT' >> $arq
    echo 'iptables -A OUTPUT -p udp --dport 53 -m state --state NEW -j ACCEPT' >> $arq
    echo 'iptables -A OUTPUT -p tcp --dport 67 -m state --state NEW -j ACCEPT' >> $arq
    echo 'iptables -A OUTPUT -p udp --dport 67 -m state --state NEW -j ACCEPT' >> $arq
    echo "iptables -t nat -A PREROUTING -i $NIC -p tcp --dport 6881:6889 -j DNAT --to-dest $IP" >> $arq
    echo "iptables -A FORWARD -p tcp -i $NIC --dport 6881:6889 -d $IP -j REJECT" >> $arq
    echo "iptables -A OUTPUT -p tcp --dport 6881:6889 -j DROP" >> $arq
    echo "iptables -A OUTPUT -p udp --dport 6881:6889 -j DROP" >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string "BitTorrent" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string "BitTorrent protocol" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string "peer_id=" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string ".torrent" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string "announce.php?passkey=" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string "torrent" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string "announce" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --algo bm --string "info_hash" -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --string "get_peers" --algo bm -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --string "announce_peer" --algo bm -j DROP' >> $arq
    echo 'iptables -A FORWARD -m string --string "find_node" --algo bm -j DROP' >> $arq

    chmod +x $arq
    $arq > /dev/null
}

# Script execution starts here
clear
echo -e "${CYAN}        ███████╗██████╗ ██╗   ██╗██╗███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ██╔════╝██╔══██╗██║   ██║██║██╔════╝██╔════╝${ENDCOLOR}"
    echo -e "${CYAN}        █████╗  ██████╔╝██║   ██║██║█████╗  █████╗  ${ENDCOLOR}"
    echo -e "${CYAN}        ██╔══╝  ██╔══██╗██║   ██║██║██╔══╝  ██╔══╝  ${ENDCOLOR}"
    echo -e "${CYAN}        ███████╗██║  ██║╚██████╔╝██║███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝╚══════╝╚══════╝${ENDCOLOR}"

echo ""
echo -e "${RED}TORRENT BLOCKER${ENDCOLOR}"
echo ""

arq="/etc/Plus-torrent"
if [[ -e "$arq" ]]; then
    read -p "$(echo -e "${GREEN}Do you want to disable Firewall Rules? ${YELLOW}[y/n]: ${WHITE}") " -e -i n resp
    if [[ "$resp" == 'y' ]]; then
        echo ""
        echo -ne "${RED}Removing Firewall Rules${ENDCOLOR}..."
        remove_script
        echo -e "${GREEN}Done.${ENDCOLOR}"
        echo ""
        echo -e "${YELLOW}Torrent blocking successfully removed.${ENDCOLOR}"
        echo ""
        echo -e "Returning to menu..."
        echo ""
        if [[ -e /etc/openvpn/openvpn-status.log ]]; then
            read -p "$(echo -e "${GREEN}Restart the system to complete? ${RED}[s/n]: ${WHITE}") " -e -i s respost
            if [[ "$respost" == 's' ]]; then
                echo -ne "${RED}Restarting"
                for i in $(seq 1 1 5); do
                    echo -n "."
                    sleep 1
                done
                reboot
            fi
        fi
        sleep 2
        menu
    else
        sleep 1
        menu
    fi
else
    read -p "$(echo -e "${GREEN}Do you want to enable Firewall Rules? ${YELLOW}[y/n]: ${WHITE}") " -e -i n resp
    if [[ "$resp" == 'y' ]]; then
        echo ""
        echo -ne "${YELLOW}Confirm your IP to continue: ${WHITE}"; read -e -i $IP IP
        if [[ -z "$IP" ]]; then
            echo ""
            echo -e "${RED}Invalid IP${ENDCOLOR}"
            sleep 1
            read -p "Enter your IP: " IP
        fi
        clear
        echo -e "${CYAN}        ███████╗██████╗ ██╗   ██╗██╗███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ██╔════╝██╔══██╗██║   ██║██║██╔════╝██╔════╝${ENDCOLOR}"
    echo -e "${CYAN}        █████╗  ██████╔╝██║   ██║██║█████╗  █████╗  ${ENDCOLOR}"
    echo -e "${CYAN}        ██╔══╝  ██╔══██╗██║   ██║██║██╔══╝  ██╔══╝  ${ENDCOLOR}"
    echo -e "${CYAN}        ███████╗██║  ██║╚██████╔╝██║███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝╚══════╝╚══════╝${ENDCOLOR}"

        echo ""
        echo -e "${YELLOW}Adding Firewall Rules${ENDCOLOR}..."
        add_firewall_rules
        echo -e "${GREEN}Done.${ENDCOLOR}"
        echo ""
        echo -e "${YELLOW}Torrent blocking successfully applied.${ENDCOLOR}"
        echo ""
        echo -e "Returning to menu..."
        sleep 3
        menu
    else
        sleep 1
        menu
    fi
fi
