#!/bin/bash

# Font colors
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
CYAN="\033[36m"
WHITE="\033[97m"
ENDCOLOR="\033[0m"

# Clear terminal
clear

# Display banner
echo -e "${CYAN}
███████╗██╗░░░██╗███████╗██████╗░██████╗░██╗░░██╗░█████╗░███████╗
██╔════╝██║░░░██║██╔════╝██╔══██╗██╔══██╗██║░░██║██╔══██╗██╔════╝
█████╗░░██║░░░██║█████╗░░███████║███████║███████║███████║█████╗░░
██╔══╝░░██║░░░██║██╔══╝░░██╔══██║██╔══██║██╔══██║██╔══██║██╔══╝░░
███████╗╚██████╔╝███████╗██║░░██║██║░░██║██║░░██║██║░░██║███████╗
╚══════╝░╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝
${ENDCOLOR}
"

echo -e "${GREEN}Available Users:${ENDCOLOR}"
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${WHITE}$allusers${ENDCOLOR}"

echo ""
echo -ne "${YELLOW}Enter the Name of the User to be deleted: ${ENDCOLOR}"; read username

# Confirm and delete user
while true; do
    read -p "Are you sure you want to delete the user $username? (Y/N): " yn
    case $yn in
        [Yy]* )
            if id "$username" &>/dev/null; then
                userdel -r $username && echo -e "\n${GREEN}User $username has been deleted successfully.${ENDCOLOR}" || echo -e "${RED}Failed to delete user $username.${ENDCOLOR}"
            else
                echo -e "${RED}User $username does not exist.${ENDCOLOR}"
            fi
            break
            ;;
        [Nn]* )
            echo -e "${RED}\nDelete action has been cancelled.${ENDCOLOR}"
            break
            ;;
        * )
            echo "Please respond with yes or no."
            ;;
    esac
done

# Return to menu
echo -e "\nPress Enter to return to the main menu"; read
menu
