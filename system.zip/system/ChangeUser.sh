#!/bin/bash

# Font colors
IP=$(cat /etc/IP)
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
CYAN="\033[36m"
ENDCOLOR="\033[0m"

# Clear terminal
clear

# Display header with new design
echo -e "${CYAN}
███████╗██╗░░░██╗███████╗██████╗░██████╗░██╗░░██╗░█████╗░███████╗
██╔════╝██║░░░██║██╔════╝██╔══██╗██╔══██╗██║░░██║██╔══██╗██╔════╝
█████╗░░██║░░░██║█████╗░░███████║███████║███████║███████║█████╗░░
██╔══╝░░██║░░░██║██╔══╝░░██╔══██║██╔══██║██╔══██║██╔══██║██╔══╝░░
███████╗╚██████╔╝███████╗██║░░██║██║░░██║██║░░██║██║░░██║███████╗
╚══════╝░╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝
${ENDCOLOR}
"

# Add users
echo -e "${YELLOW}Enter the username:${ENDCOLOR}"; read username

while true; do
    read -p "Generate a random password? (Y/N): " yn
    case $yn in
        [Yy]* ) password=$(< /dev/urandom tr -dc _A-Z-a-z-0-9 | head -c${1:-12}; echo); break;;
        [Nn]* ) echo -ne "Enter password (use a strong password): ${ENDCOLOR}"; read password; break;;
        * ) echo "Please answer Y or N.";;
    esac
done

echo -ne "Enter number of days until expiration: "; read nod
exd=$(date +%F -d "$nod days")

# Update user details
chage -E $exd $username && echo "$username:$password" | chpasswd

clear

# Display completion message with new design
echo -e "${CYAN}
███████╗██╗░░░██╗███████╗██████╗░██████╗░██╗░░██╗░█████╗░███████╗
██╔════╝██║░░░██║██╔════╝██╔══██╗██╔══██╗██║░░██║██╔══██╗██╔════╝
█████╗░░██║░░░██║█████╗░░███████║███████║███████║███████║█████╗░░
██╔══╝░░██║░░░██║██╔══╝░░██╔══██║██╔══██║██╔══██║██╔══██║██╔══╝░░
███████╗╚██████╔╝███████╗██║░░██║██║░░██║██║░░██║██║░░██║███████╗
╚══════╝░╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝
${ENDCOLOR}
"

# Display account information
echo -e "${GREEN}========== SSH & OVPN Account ==========${ENDCOLOR}"
echo -e "${GREEN}\n• IP Address: ${YELLOW}$s_ip${ENDCOLOR}"
echo -e "${GREEN}\n• Username: ${YELLOW}$username${ENDCOLOR}"
echo -e "${GREEN}\n• Password: ${YELLOW}$password${ENDCOLOR}"
echo -e "${GREEN}\n• Expire Date: ${YELLOW}$exd${ENDCOLOR}"

# Display port and service information
echo -e "${GREEN}\n================= Port =================${ENDCOLOR}"
echo -e "${GREEN}\n• Badvpn: ${YELLOW}1-65535${ENDCOLOR}"

echo -e "${GREEN}\n========== Http Custom UDP ===========${ENDCOLOR}"
echo -e "${YELLOW}$s_ip:1-65535@$username:$password${ENDCOLOR}"

# Contact information
echo -e "${GREEN}=======================================${ENDCOLOR}"
echo -e ">> Contact on Telegram: @NEW_CRAZY_OWNER_OFFICAL1"
echo -e "${GREEN}=======================================${ENDCOLOR}"

# Return to panel
echo -e "\nPress Enter to return to the main menu"; read
menu
