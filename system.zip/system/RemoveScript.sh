#!/bin/bash

# Font colors
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[34m"
CYAN="\033[36m"
WHITE="\033[97m"
ENDCOLOR="\033[0m"

# Loading spinner function
spinner() {
    local pid=$!
    local delay=0.75
    local spinstr='|/-\\'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

# Remove script function
remove_script() {
    echo -e "${YELLOW}Stopping services and removing files...${ENDCOLOR}"
    systemctl stop udp-custom
    rm -rf /root/udp
    rm -rf /etc/Sslablk1
    systemctl daemon-reload
    rm -f /usr/local/bin/menu
    sed -i ':a;N;$!ba;s/\n\/bin\/false//g' /etc/shells
}

# Confirm removal function
remove_confirm() {
    echo -ne "${RED}● Removing Script       ..."
    remove_script >/dev/null 2>&1 &
    spinner
    echo -ne "\tdone"
    echo -e "${ENDCOLOR}"
}

# Main script
clear
echo -e "${CYAN}
███████╗██╗░░░██╗███████╗██████╗░██████╗░██╗░░██╗░█████╗░███████╗
██╔════╝██║░░░██║██╔════╝██╔══██╗██╔══██╗██║░░██║██╔══██╗██╔════╝
█████╗░░██║░░░██║█████╗░░███████║███████║███████║███████║█████╗░░
██╔══╝░░██║░░░██║██╔══╝░░██╔══██║██╔══██║██╔══██║██╔══██║██╔══╝░░
███████╗╚██████╔╝███████╗██║░░██║██║░░██║██║░░██║██║░░██║███████╗
╚══════╝░╚═════╝░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝
${ENDCOLOR}
"

echo -e "${WHITE}Thank You For Using This Script"
echo -e "${WHITE}By Project SL CAT EHI TEAM${ENDCOLOR}"
echo ""

# User confirmation to remove script
while true; do
    read -p "Do you want to remove the script? (Y/N): " yn
    case $yn in
        [Yy]* )
            remove_confirm
            echo -e "${GREEN}Remove Complete. Press Enter key to exit.${ENDCOLOR}"
            read
            exit
            ;;
        [Nn]* )
            echo -e "${RED}Remove aborted! Press Enter key to return to the main menu.${ENDCOLOR}"
            read
            menu
            exit
            ;;
        * )
            echo "Please answer yes or no."
            ;;
    esac
done
