#!/bin/bash

# Color definitions
GREEN="\033[32m"
CYAN="\033[36m"
YELLOW="\033[33m"
WHITE="\033[97m"
ENDCOLOR="\033[0m"

# Function to print header
print_header() {
    echo -e "${CYAN}        ███████╗██████╗ ██╗   ██╗██╗███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ██╔════╝██╔══██╗██║   ██║██║██╔════╝██╔════╝${ENDCOLOR}"
    echo -e "${CYAN}        █████╗  ██████╔╝██║   ██║██║█████╗  █████╗  ${ENDCOLOR}"
    echo -e "${CYAN}        ██╔══╝  ██╔══██╗██║   ██║██║██╔══╝  ██╔══╝  ${ENDCOLOR}"
    echo -e "${CYAN}        ███████╗██║  ██║╚██████╔╝██║███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝╚══════╝╚══════╝${ENDCOLOR}"
}

# Function to list all users
list_users() {
    echo -e "${YELLOW}Fetching all users with UID >= 1000...${ENDCOLOR}"
    allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
    echo -e "${GREEN}$allusers${ENDCOLOR}"
}

# Function to return to menu
return_to_menu() {
    echo -e "\n${CYAN}Press Enter key to return to main menu${ENDCOLOR}"
    read
    menu
}

# Main script execution
clear
print_header
echo ""
list_users
return_to_menu
