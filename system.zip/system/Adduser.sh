#!/bin/bash

# Font colors
RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
CYAN="\033[36m"
ENDCOLOR="\033[0m"

# Fetch IP address
s_ip=$(wget -qO- https://ipecho.net/plain ; echo)

# Clear the terminal
clear

# Display header art
echo -e "${CYAN}        ███████╗██████╗ ██╗   ██╗██╗███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ██╔════╝██╔══██╗██║   ██║██║██╔════╝██╔════╝${ENDCOLOR}"
    echo -e "${CYAN}        █████╗  ██████╔╝██║   ██║██║█████╗  █████╗  ${ENDCOLOR}"
    echo -e "${CYAN}        ██╔══╝  ██╔══██╗██║   ██║██║██╔══╝  ██╔══╝  ${ENDCOLOR}"
    echo -e "${CYAN}        ███████╗██║  ██║╚██████╔╝██║███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝╚══════╝╚══════╝${ENDCOLOR}"

# User input
echo -ne "${YELLOW}Enter the username: ${ENDCOLOR}"; read username
while true; do
    read -p "Generate a random password? (Y/N): " yn
    case $yn in
        [Yy]* ) password=$(< /dev/urandom tr -dc _A-Z-a-z-0-9 | head -c${1:-12}; echo); break;;
        [Nn]* ) echo -ne "Enter password (use a strong password): ${ENDCOLOR}"; read password; break;;
        * ) echo "Please answer Y or N.";;
    esac
done

echo -ne "Enter the number of days until expiration: "; read nod
exd=$(date +%F -d "$nod days")

echo -ne "Enter the max logins limit: "; read maxlogins
echo "$username  hard  maxlogins $maxlogins" > /etc/security/limits.d/"$username"

useradd -e $exd -M -N -s /bin/false $username && echo "$username:$password" | chpasswd

clear

# Display completion art
echo -e "${CYAN}        ███████╗██████╗ ██╗   ██╗██╗███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ██╔════╝██╔══██╗██║   ██║██║██╔════╝██╔════╝${ENDCOLOR}"
    echo -e "${CYAN}        █████╗  ██████╔╝██║   ██║██║█████╗  █████╗  ${ENDCOLOR}"
    echo -e "${CYAN}        ██╔══╝  ██╔══██╗██║   ██║██║██╔══╝  ██╔══╝  ${ENDCOLOR}"
    echo -e "${CYAN}        ███████╗██║  ██║╚██████╔╝██║███████╗███████╗${ENDCOLOR}"
    echo -e "${CYAN}        ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝╚══════╝╚══════╝${ENDCOLOR}"

# Display account information
echo -e "${GREEN}========== SSH & OVPN Account ==========${ENDCOLOR}"
echo -e "${GREEN}• IP Address: ${YELLOW}$s_ip${ENDCOLOR}"
echo -e "${GREEN}• Username: ${YELLOW}$username${ENDCOLOR}"
echo -e "${GREEN}• Password: ${YELLOW}$password${ENDCOLOR}"
echo -e "${GREEN}• Expiration Date: ${YELLOW}$exd${ENDCOLOR}"
echo -e "${GREEN}• Max Logins: ${YELLOW}$maxlogins${ENDCOLOR}"

# Port and service information
echo -e "${GREEN}================= Port =================${ENDCOLOR}"
echo -e "${GREEN}• Badvpn: ${YELLOW}1-65535${ENDCOLOR}"

echo -e "${GREEN}========== HTTP Custom UDP ===========${ENDCOLOR}"
echo -e "${YELLOW}$s_ip:1-65535@$username:$password${ENDCOLOR}"

# Contact information
echo -e "${GREEN}=======================================${ENDCOLOR}"
echo -e ">> Contact on Telegram: @NEW_CRAZY_OWNER_OFFICAL1"
echo -e "${GREEN}=======================================${ENDCOLOR}"

# Return to panel
echo -e "\nPress Enter to return to the main menu"; read
menu
